package logic;

import java.sql.SQLException;

import UI.UIlogic;
import entiy.payroll;

public class client {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
        UIlogic UI=new UIlogic();
        payroll p=UI.createpayroll(1);
        p.print();
	}

}
