package UI;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;

import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JButton;

import entiy.payroll;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class printpoyroll extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID =2;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JLabel label_7;
	//UIlogic UI;
	payroll roll=UIlogic.roll;
	//private static payroll rolll;
	static printpoyroll frame;
     

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new printpoyroll();
					frame.setVisible(true);
					//setRoll(UIlogic.getRoll());
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public printpoyroll() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 678, 396);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u59D3\u540D\uFF1A");
		lblNewLabel.setBounds(73, 38, 54, 15);
		contentPane.add(lblNewLabel);
		
		JLabel label = new JLabel("\u5E74\u9F84\uFF1A");
		label.setBounds(73, 144, 54, 15);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("\u5DE5\u53F7\uFF1A");
		label_1.setBounds(73, 197, 54, 15);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("\u7535\u8BDD:");
		label_2.setBounds(73, 250, 54, 15);
		contentPane.add(label_2);
		
		JLabel label_3 = new JLabel("\u804C\u4F4D\uFF1A");
		label_3.setBounds(73, 303, 54, 15);
		contentPane.add(label_3);
		
		JLabel label_4 = new JLabel("\u6027\u522B\uFF1A");
		label_4.setBounds(73, 91, 54, 15);
		contentPane.add(label_4);
		
		textField = new JTextField();
		textField.setEditable(false);
		textField.setBounds(119, 35, 101, 18);
		textField.setText(roll.getWorker().getName());
		contentPane.add(textField);
		textField.setColumns(10);
	
		textField_1 = new JTextField();
		textField_1.setEditable(false);
		textField_1.setBounds(119, 88, 101, 18);
		textField_1.setText(roll.getWorker().getSex());
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setEditable(false);
		textField_2.setBounds(119, 141, 101, 18);
		textField_2.setText(String.valueOf(roll.getWorker().getAge()));
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setEditable(false);
		textField_3.setBounds(119, 194, 101, 18);
		textField_3.setText(String.valueOf(roll.getWorker().getID()));
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setEditable(false);
		textField_4.setBounds(119, 247, 101, 18);
		textField_4.setText(roll.getWorker().getPhone());
		contentPane.add(textField_4);
		textField_4.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setEditable(false);
		textField_5.setBounds(119, 303, 101, 18);
		textField_5.setText(roll.getWorker().getPosition());
		contentPane.add(textField_5);
		textField_5.setColumns(10);
		
		JLabel label_5 = new JLabel("\u57FA\u672C\u5DE5\u8D44\uFF1A");
		label_5.setBounds(279, 91, 76, 15);
		contentPane.add(label_5);
		
		JLabel label_6 = new JLabel("\u4F4F\u623F\u8865\u52A9\u91D1\uFF1A");
		label_6.setBounds(279, 144, 83, 15);
		contentPane.add(label_6);
		
		JLabel lblNewLabel_1 = new JLabel("\u603B\u5DE5\u8D44\uFF1A");
		lblNewLabel_1.setFont(new Font("SimSun", Font.PLAIN, 12));
		lblNewLabel_1.setBounds(528, 144, 101, 15);
		contentPane.add(lblNewLabel_1);
		
		textField_6 = new JTextField();
		textField_6.setEditable(false);
		textField_6.setBounds(576, 141, 76, 21);
		textField_6.setText(String.valueOf(roll.getWorker().getTotal()));
		contentPane.add(textField_6);
		textField_6.setColumns(10);
		
		textField_7 = new JTextField();
		textField_7.setEditable(false);
		textField_7.setBounds(403, 88, 66, 21);
		textField_7.setText(String.valueOf(roll.getSalary().getBasicsalary()));
		contentPane.add(textField_7);
		textField_7.setColumns(10);
		
		textField_8 = new JTextField();
		textField_8.setEditable(false);
		textField_8.setBounds(403, 141, 66, 21);
		textField_8.setText(String.valueOf(roll.getSalary().getHousingallowance()));
		contentPane.add(textField_8);
		textField_8.setColumns(10);
		
		textField_9 = new JTextField();
		textField_9.setEditable(false);
		textField_9.setBounds(403, 188, 66, 21);
		textField_9.setText(String.valueOf(roll.getSalary().getBonus()));
		contentPane.add(textField_9);
		textField_9.setColumns(10);
		
		label_7 = new JLabel("\u5956\u91D1\uFF1A");
		label_7.setBounds(279, 194, 101, 15);
		contentPane.add(label_7);
		
		JButton button_1 = new JButton("\u8FD4\u56DE");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mainUI m=new mainUI();
				m.setVisible(true);
				}
		});
		button_1.setBounds(559, 324, 93, 23);
		contentPane.add(button_1);
	}

}
