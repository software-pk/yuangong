package UI;


import java.sql.SQLException;
import java.util.ArrayList;
import DAO.employeeDAO;
import DAO.salaryDAO;
import entiy.employee;
import entiy.payroll;
import entiy.salary;
public class UIlogic {
	public static UIlogic UI=new UIlogic();
	//protected static final String UI = null;
	public static ArrayList<employee> line = new ArrayList<employee> ();
	public static ArrayList<salary> aline = new ArrayList<salary> ();
	public static payroll roll;
	
	public UIlogic()
	{
		employeeDAO e=new employeeDAO();
		salaryDAO s=new salaryDAO();
		/*employee e=new employee("������","Ů",20,1,"����","18463102771",10000);
		salary s=new salary(6000,2000,2000,1);
		line.add(e);
		aline.add(s);
		setRoll(new payroll(e,s));*/
	}
	public int IDOK(int ID)
	{
		employee[] list = (employee[]) line.toArray(new employee[1]);
		for (int i = 0; i < list.length; i++) 
		{
			if(ID==list[i].getID())
				return 1;
		}
		return 0;
	}
	
	public payroll createpayroll(int ID)
	{
		int i,j;
		employee[] list = (employee[]) line.toArray(new employee[1]);
		for ( i = 0; i < list.length; i++) 
		{
			if(ID==list[i].getID()) break;
		}
		salary[] alist = (salary[]) aline.toArray(new salary[1]);
		for ( j = 0; j < alist.length; j++) 
		{
			if(ID==alist[j].getID()) break;
		}
		setRoll(new payroll(line.get(i),aline.get(j)));
		return roll;
	}
	private void setRoll(payroll payroll) {
		// TODO Auto-generated method stub
		this.roll=payroll;
	}
}
