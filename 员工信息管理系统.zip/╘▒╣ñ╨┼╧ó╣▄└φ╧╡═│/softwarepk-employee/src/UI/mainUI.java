package UI;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import entiy.employee;
import entiy.payroll;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
public class mainUI extends JFrame {

	/**
	 * 
	 */
	//private static final long serialVersionUID = 1;
	private JPanel contentPane;
	private JButton button;
	//private final static UIlogic UI=new UIlogic();
	private JTable table;
	private JTextField textField;
	String ID;
	static mainUI frame;
	/**
	 * Launch the application.
	 * @return 
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
				    frame = new mainUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public mainUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 709, 448);
		contentPane = new JPanel();
		contentPane.setForeground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		//contentPane.add(button);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 693, 399);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel label = new JLabel("\u5458\u5DE5\u4FE1\u606F\u7BA1\u7406\u7CFB\u7EDF");
		label.setFont(new Font("�����п�", Font.BOLD, 29));
		label.setBounds(37, 21, 359, 65);
		panel.add(label);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(34, 96, 632, 293);
		{
			employee[] l= (employee[]) UIlogic.line.toArray(new employee[1]);
			Object list[][]=new Object[l.length][7];
			//employee[] l= (employee[]) UI.line.toArray(new employee[1]);
				for (int i = 0; i < l.length; i++)
				{
				list[i][0]= l[i].getName();
				list[i][1]= l[i].getSex();
				list[i][2]= l[i].getAge();
				list[i][3]= l[i].getID();
				list[i][4]= l[i].getPosition();
				list[i][5]= l[i].getPhone();
				list[i][6]= l[i].getTotal();
				}
			TableModel jTable1Model = 
				new DefaultTableModel(list,new String[] { "����", "�Ա�","����","����","ְλ","�绰","�ܹ���"});	
			table = new JTable();
			table.setModel(jTable1Model);
		    scrollPane.setColumnHeaderView(table);
		    
			table.setPreferredSize(new java.awt.Dimension(596, 187));
		}
		panel.add(scrollPane);
		
		JLabel label_1 = new JLabel("\u5DE5\u53F7\uFF1A");
		label_1.setBounds(406, 61, 47, 25);
		panel.add(label_1);
		
		textField = new JTextField();
		textField.setBounds(463, 61, 86, 25);
		panel.add(textField);
		textField.setColumns(10);
	ID=textField.getText();
		
		JButton button_1 = new JButton("\u67E5\u8BE2");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(UIlogic.UI.IDOK(Integer.valueOf(ID))==1)
				{
				UIlogic.UI.createpayroll(Integer.valueOf(ID));
				printpoyroll p=new printpoyroll();
				SwingUtilities.updateComponentTreeUI (p);
				p.setVisible(true);
				}
			}
		});
		button_1.setBounds(559, 61, 104, 25);
		panel.add(button_1);
	}
}
