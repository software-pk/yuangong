package entiy;

public class salary {
    private int basicsalary;
   	private int bonus;
    private int housingallowance;
    private int ID;
       
     public salary(int basicsalary,int bonus,int housingallowance,int ID)
     {
    	 setBasicsalary(basicsalary);
    	 setBonus(bonus);
    	 setHousingallowance(housingallowance);
    	 setID(ID);
     }
       
     public void print()
     {
       System.out.println("basic salary:"+getBasicsalary());
       System.out.println("bonus:"+getBonus());
       System.out.println("housingallowance:"+getHousingallowance());
       System.out.println("ID:"+getID());
     }
       
    public salary()
    {
    	
    }
    public int getBasicsalary() {
		return basicsalary;
	}
	public void setBasicsalary(int basicsalary) {
		this.basicsalary = basicsalary;
	}
	public int getBonus() {
		return bonus;
	}
	public void setBonus(int bonus) {
		this.bonus = bonus;
	}
	public int getHousingallowance() {
		return housingallowance;
	}
	public void setHousingallowance(int housingallowance) {
		this.housingallowance = housingallowance;
	}
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}

}
