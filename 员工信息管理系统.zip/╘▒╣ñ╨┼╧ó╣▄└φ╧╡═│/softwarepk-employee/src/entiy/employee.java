package entiy;

public class employee {
      private String name;
      private String sex;
      private int age;
      private int ID;
      private int Total;
      private String position;
      private String phone;
      
    public employee(String name,String sex,int age,int ID,String position,String phone,int Total)
    {
      setName(name);
      setSex(sex);
      setAge(age);
      setPosition(position);
      setPhone(phone);
      setID(ID);
      setTotal(Total);
    }
    public employee(){
    	
    }
	public void print() {
		// TODO Auto-generated method stub
	      System.out.println("name:"+getName());
	      System.out.println("sex:"+getSex());
	      System.out.println("age:"+getAge());
	      System.out.println("ID:"+getID());
	      System.out.println("position:"+getPosition());
	      System.out.println("phone:"+getPhone());
	      System.out.println("Total:"+getTotal());
	}
    
    public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public int getTotal() {
		return Total;
	}
	public void setTotal(int total) {
		Total = total;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

}
