package entiy;

public class payroll {
	
	public employee worker=new employee();
	public salary  salary=new salary();

	public payroll(employee worker,salary salary)
	{
		setWorker(worker);
		setSalary(salary);
	}
	
	public void print()
	{
		getWorker().print();
		getSalary().print();	
	}
	
	
	public employee getWorker() {
		return worker;
	}
	public void setWorker(employee worker) {
		this.worker = worker;
	}
	public salary getSalary() {
		return salary;
	}
	public void setSalary(salary salary) {
		this.salary = salary;
	}

}
